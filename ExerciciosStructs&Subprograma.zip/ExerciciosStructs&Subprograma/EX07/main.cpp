#include <iostream>

using namespace std;


int conversao(int anos, int meses, int dias) {
    int idade_em_dias = (anos*360) + (meses*30) + dias;
    return idade_em_dias;
}

int main() {

    int anos, meses, dias;

    cout << "Anos: " << endl;
    cin >> anos;

    cout << "Meses: " << endl;
    cin >> meses;

    cout << "Dias: " << endl;
    cin >> dias;

    int idade_em_dias = conversao(anos, meses, dias);
    cout << "Sua idade em dias eh " << idade_em_dias << endl;

    system("pause");
    return 0;
}
