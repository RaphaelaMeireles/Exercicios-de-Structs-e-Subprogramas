#include <iostream>
#include <cstdlib>
#include <cstring>

using namespace std;

double calculoPeso(float altura, char sexo[30]) {
    double pesoIdeal = 0;
    if(stricmp(sexo, "Masculino") == 0) {
        pesoIdeal = 72.7 * altura - 58;
    }
    else if(stricmp(sexo, "Feminino") == 0) {
        pesoIdeal = 62.1 * altura - 44.7;
    }

    return pesoIdeal;
}

int main() {

    float altura;
    char sexo[30];

    cout << "Insira sua altura:" << endl;
    cin >> altura;

    fflush(stdin);

    cout << "Insira seu sexo (Feminino ou Masculino):" << endl;
    cin.getline(sexo, size(sexo));

    double resultado = calculoPeso(altura, sexo);
    cout << "\nO seu peso ideal eh: " << resultado << endl;

    system("pause");
    return 0;
}
