#include <iostream>

using namespace std;

float conversaoGraus(float grausF);

int main()
{
    float grausF;

    for (int i = 0; i <= 100; ++i) {
        grausF = i;
        float grausC = conversaoGraus(grausF);
        cout << "Graus em Fahrenheit = " << grausF << " || Em celsius = " << grausC << endl;
    }

    system("pause");
    return 0;
}

float conversaoGraus(float grausF) {
    float grausC = (grausF-32)*5/9;
    return grausC;
}
