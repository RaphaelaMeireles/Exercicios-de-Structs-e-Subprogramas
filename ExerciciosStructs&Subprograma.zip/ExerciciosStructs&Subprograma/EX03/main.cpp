#include <iostream>

using namespace std;

int calcular(int paisA, int paisB) {
    int anos = 0;
    while (paisA < paisB) {
        paisA += paisA * 0.03;
        paisB += paisB * 0.015;

        anos++;
    }
    return anos;
}

int main()
{
    int paisA = 90000000;
    int paisB = 200000000;

    int resultado = calcular(paisA, paisB);
    cout << "Para que a populacao do pais A ultrapasse ou seja igual a populacao do pais B seram necessarios: " << resultado << " anos."<< endl;

    system("pause");
    return 0;
}
