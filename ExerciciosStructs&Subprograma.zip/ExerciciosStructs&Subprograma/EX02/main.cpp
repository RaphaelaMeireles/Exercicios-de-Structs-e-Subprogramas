#include <iostream>
#include <limits>

using namespace std;

float calcularMaior(float num[3]);

int main()
{
    float num[3];

    for (int i = 0; i < 3; ++i) {
        cout << "Digite um numero: " << endl;
        cin >> num[i];
    }

    float maior = calcularMaior(num);
    cout << "O maior valor eh: " << maior << endl;

    system("pause");
    return 0;
}

float calcularMaior(float num[3]) {
    float maior = 0;
    for (int i = 0; i < 3; ++i) {
        if (num[i] > maior) {
            maior = num[i];
        }
    }
    return maior;
}
