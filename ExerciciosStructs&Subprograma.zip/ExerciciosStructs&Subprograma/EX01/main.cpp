#include <iostream>
#include <cstring>

using namespace std;

struct Aluno{
    char nome[100];
    int matricula;
};

int main() {

    Aluno dados[50];

        for (int i = 0; i < 50; ++i) {
            cout << "Digite o nome do aluno: " << endl;
            fflush(stdin);
            cin.getline(dados[i].nome, size(dados));

            cout << "Digite o numero da matricula: " << endl;
            cin >> dados[i].matricula;
        }

    for (int i = 0; i < 50; ++i) {
        cout << "Aluno(a): " << dados[i].nome << endl;
        cout << "Matricula: " << dados[i].matricula << endl;
        cout << "\n";
    }

    system("pause");
    return 0;
}

