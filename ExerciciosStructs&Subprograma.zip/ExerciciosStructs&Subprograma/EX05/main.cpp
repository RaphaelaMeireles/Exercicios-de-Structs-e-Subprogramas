#include <iostream>

using namespace std;

void categoria(int idade) {
    if (idade < 5) {
        cout << "Idade abaixo do necessario para participar!";
    }
    else if(idade >= 5 && idade <= 7) {
        cout << "Sua categoria eh: Infantil A";
    }
    else if(idade >= 8 && idade <= 10) {
        cout << "Sua categoria eh: Infantil B";
    }
    else if(idade >= 11 && idade <= 13) {
        cout << "Sua categoria eh: Juvenil A";
    }
    else if(idade >= 14 && idade <= 17) {
        cout << "Sua categoria eh: Juvenil B";
    }
    else if(idade >= 18) {
        cout << "Sua categoria eh: Adulto";
    }
}

int main()
{
    int idade;

    cout << "Insira a idade do nadador:" << endl;
    cin >> idade;

    categoria(idade);

    return 0;
}
